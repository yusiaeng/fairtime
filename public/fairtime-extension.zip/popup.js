
const $ = (id) => document.getElementById(id);
const api = "http://localhost:3000";

let busy = false;
let demoMeeting = null;

const names = {
  alice: "Alice",
  bob: "Bob",
  charlie: "Charlie"
};

const format = (date) =>
  new Date(date).toLocaleString("en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Europe/London"
  });

const selected = () =>
  [...document.querySelectorAll(".people input:checked")]
    .map((input) => input.value);

function show(message) {
  $("status").textContent = message;
}

function node(tag, cls = "", text) {
  const element = document.createElement(tag);
  if (cls) element.className = cls;
  if (text !== undefined) element.textContent = text;
  return element;
}

function button(label, action) {
  const element = node("button", "confirm", label);
  element.addEventListener("click", action);
  return element;
}

async function request(path, data) {
  const response = await fetch(api + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Request failed");
  }

  return result;
}

function saveDemo() {
  chrome.storage.local.set({
    fairtimeDemo: demoMeeting
  });
}

function renderVoting() {
  if (!demoMeeting) return;

  const results = $("results");
  results.replaceChildren();

  const card = node("article", "result");

  card.append(
    node("h2", "", "✦ FairTime Meeting")
  );

  card.append(
    node("p", "", demoMeeting.name)
  );

  card.append(
    node("p", "", format(demoMeeting.start))
  );

  card.append(
    node(
      "p",
      "explain",
      demoMeeting.confirmed
        ? "✓ Meeting created in Google Calendar."
        : "Demo meeting proposal — no calendar event created."
    )
  );

  card.append(
    node("h2", "", "Team Invitations")
  );

  card.append(
    node(
      "p",
      "explain",
      "Demo mode: invitations and responses are simulated. No emails are sent."
    )
  );

  if (!demoMeeting.sent) {
    card.append(
      button("Send Demo Invitations →", () => {
        demoMeeting.sent = true;
        saveDemo();
        renderVoting();
        show("Demo invitations sent to the selected team.");
      })
    );
  } else {
    demoMeeting.people.forEach((id) => {
      const person = node("div", "result");

      const status = demoMeeting.responses[id] || "Pending";

      person.append(
        node("h2", "", names[id] || id)
      );

      person.append(
        node("p", "", `Status: ${status}`)
      );

      person.append(
        button("✓ Accept", () => {
          demoMeeting.responses[id] = "Accepted";
          saveDemo();
          renderVoting();
          show(`${names[id]} accepted the meeting (demo).`);
        })
      );

      person.append(
        button("↻ Request Change", () => {
          demoMeeting.responses[id] = "Requested change";
          saveDemo();
          renderVoting();
          show(`${names[id]} requested another time (demo).`);
        })
      );

      card.append(person);
    });

    const statuses = demoMeeting.people.map(
      (id) => demoMeeting.responses[id]
    );

    if (statuses.every((s) => s === "Accepted")) {
      card.append(
        node(
          "p",
          "success",
          "✓ Everyone accepted! Meeting agreed."
        )
      );
    }

    if (statuses.includes("Requested change")) {
      card.append(
        node(
          "p",
          "explain",
          "A team member requested a different time."
        )
      );

      card.append(
        button("Find Another Fair Time →", () => {
          demoMeeting = null;
          saveDemo();
          $("results").replaceChildren();
          show("Choose new dates and find another fair time.");
        })
      );
    }
  }

  if (demoMeeting.eventLink) {
    const link = node(
      "a",
      "",
      "View Google Calendar Event ↗"
    );

    link.href = demoMeeting.eventLink;
    link.target = "_blank";
    link.rel = "noopener noreferrer";

    card.append(link);
  }

  card.append(
    button("Start New Meeting", () => {
      demoMeeting = null;
      saveDemo();
      $("results").replaceChildren();
      show("Ready to schedule another meeting.");
    })
  );

  results.append(card);
}



$("find").addEventListener("click", async () => {
  if (busy) return;

  const name = $("name").value.trim();
  const people = selected();
  const start = $("startDate").value;
  const deadline = $("deadline").value;

  if (
    !name ||
    !people.length ||
    !start ||
    !deadline ||
    deadline < start
  ) {
    show("Enter valid meeting details.");
    return;
  }

  const searchStart = `${start}T00:00:00Z`;

  const endDate = new Date(`${deadline}T00:00:00Z`);
  endDate.setUTCDate(endDate.getUTCDate() + 1);

  const searchEnd = endDate.toISOString();

  if (
    Date.parse(searchEnd) - Date.parse(searchStart) >
    7 * 86400000
  ) {
    show("Choose a date range of 7 days or fewer.");
    return;
  }

  busy = true;
  $("find").disabled = true;
  $("results").replaceChildren();

  show("Checking calendars and finding fair times…");

  try {
    const data = await request(
      "/api/calendar/google/recommend",
      {
        searchStart,
        searchEnd,
        durationMinutes: Number($("duration").value),
        participants: people
      }
    );

    const recommendations = data.recommendations || [];

    if (!recommendations.length) {
      show("No available times found.");
      return;
    }

    show(
      `${recommendations.length} fair times found · London time`
    );

    recommendations.forEach((rec, index) => {
      const card = node("article", "result");

      card.append(
        node(
          "h2",
          "",
          index === 0
            ? "★ #1 Fairest Option"
            : `#${index + 1} Alternative`
        )
      );

      card.append(
        node(
          "p",
          "",
          `${format(rec.slot.start)} – ${new Date(
            rec.slot.end
          ).toLocaleTimeString("en-GB", {
            hour: "2-digit",
            minute: "2-digit",
            timeZone: "Europe/London"
          })}`
        )
      );

      card.append(
        node(
          "p",
          "explain",
          `⚖️ Fairness score: ${rec.maxCumulativeInconvenience}. ` +
          `Total inconvenience: ${rec.totalCumulativeInconvenience}. ` +
          "FairTime balances scheduling inconvenience across the team."
        )
      );

      function openDemo(confirmed, eventLink = null) {
        demoMeeting = {
          name,
          start: rec.slot.start,
          end: rec.slot.end,
          people,
          responses: Object.fromEntries(
            people.map((id) => [id, "Pending"])
          ),
          sent: false,
          confirmed,
          eventLink
        };

        saveDemo();
        renderVoting();
      }

      card.append(
        button("Preview Invitations & Voting (Demo)", () => {
          openDemo(false);
          show("Demo meeting ready. Send demo invitations!");
        })
      );

      const confirmButton = button(
        "Confirm on Google Calendar",
        async () => {
          if (busy) return;

          busy = true;
          confirmButton.disabled = true;

          show("Creating Google Calendar event…");

          try {
            const result = await request(
              "/api/calendar/google/confirm",
              {
                meetingName: name,
                start: rec.slot.start,
                end: rec.slot.end,
                participants: people
              }
            );

            openDemo(true, result.eventLink || null);

            show(
              "✓ Calendar event created. Send demo invitations!"
            );
          } catch (error) {
            show(error.message);
            confirmButton.disabled = false;
          } finally {
            busy = false;
          }
        }
      );

      card.append(confirmButton);

      $("results").append(card);
    });
  } catch (error) {
    show(error.message);
  } finally {
    busy = false;
    $("find").disabled = false;
  }
});
