# FairTime Chrome Extension — working local launcher MVP

This Chrome Manifest V3 extension launches the existing, already working
Next.js `/demo` scheduler in a compact separate browser window. The page itself
calls the existing same-origin `/api/calendar/google/recommend` and
`/api/calendar/google/confirm` endpoints, so **no backend code, CORS bypass,
extra OAuth scopes, or API keys inside the extension are needed**.

## Install

1. From your FairTime repository run `npm run dev` and verify that
   `http://localhost:3000/demo` works in Chrome.
2. Unzip this package (if downloaded as a ZIP).
3. Open `chrome://extensions` in Chrome.
4. Enable **Developer mode**.
5. Click **Load unpacked** and select the **fairtime-chrome-extension** folder
   (the one containing `manifest.json`).
6. Pin **FairTime** using Chrome's puzzle-piece toolbar menu.
7. Click the FairTime icon, then **Schedule a fair meeting**.
8. Choose participants, find fair times, and confirm a test meeting. It will
   write to the same Google account's primary calendar as the working website.

## Important limitations

- Your Next.js development server must be running on port 3000.
- This is an **extension-launched app window**, not an embedded extension form,
  Chrome side panel, in-page Grammarly bubble, or cross-user notification system.
- It uses your existing local demo Google OAuth credentials; do not publish
  or share the local backend or secrets.
- Confirm creates an event on the demo account's main calendar. It does not
  send invitations or gather consent from separate users.
- Keep the website as the source of truth. Later, both website and a native
  extension UI should use shared authenticated Next.js APIs for proposals,
  responses, notifications, and TigerData history.

## Architecture for later integration

Chrome extension UI --> Next.js authenticated API --> fairness engine,
Google Calendar, Gemini explanations, TigerData persistence.

For production, replace this local launcher with a native popup/side panel,
secure user auth, per-user calendar tokens, proposal and voting endpoints, and
notification delivery. Never loosen the existing development-only endpoint
origin checks just to permit arbitrary Chrome extensions.
